from sklearn.feature_selection import SequentialFeatureSelector
from benchmark import benchmark

class SequentialSelector:
    def __init__(self, estimator_name, direction = "forward", n_features = None, tol = None, **params):
        self.estimator_name = estimator_name
        self.estimator = None
        self.model = None
        self.direction = direction
        self.n_features = n_features
        self.tol = tol

        if self.estimator_name == 'LinearSVC':
            from sklearn.svm import LinearSVC
            self.estimator = LinearSVC(**params)

    # build selector
    def fit(self, trainX, trainY, tol = None, n_features = "auto", direction = "forward"): 
        self.model = SequentialFeatureSelector(self.estimator, direction=direction, n_features_to_select=n_features, tol=self.tol)
        print(self.model)
        self.model = self.model.fit(trainX, trainY)
    
    # select features
    def transform(self, trainX):
        return self.model.transform(trainX)

    def fit_and_transform(self, trainX, trainY, n_features = "auto"):
        self.fit(trainX, trainY, n_features = n_features, direction = self.direction, tol=self.tol)
        return self.transform(trainX)
