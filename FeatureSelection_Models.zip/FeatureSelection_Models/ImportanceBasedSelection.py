import statistics

import numpy as np
from sklearn.feature_selection import SelectFromModel
from benchmark import benchmark

class ImportanceBasedSelector:
    def __init__(self, estimator_name, n_features = None, threshold = -np.inf, **params):
        self.estimator_name = estimator_name
        self.estimator = None
        self.model = None
        self.n_features = n_features
        self.threshold = threshold

        if self.estimator_name == 'LinearSVC':
            from sklearn.svm import LinearSVC
            self.estimator = LinearSVC(**params)
        elif self.estimator_name == 'ExtraTrees':
            from sklearn.ensemble import ExtraTreesClassifier
            self.estimator = ExtraTreesClassifier(**params)
        elif self.estimator_name == 'Ridge':
            from sklearn.linear_model import RidgeCV
            self.estimator = RidgeCV(**params)
        elif self.estimator_name == 'LogisticRegression':
            from sklearn.linear_model import LogisticRegression
            self.estimator = LogisticRegression(**params)
        elif self.estimator_name == 'RandomForest':
            from sklearn.ensemble import RandomForestClassifier
            self.estimator = RandomForestClassifier(**params)
        elif self.estimator_name == 'DecisionTree':
            from sklearn.tree import DecisionTreeClassifier
            self.estimator = DecisionTreeClassifier(**params)
        elif self.estimator_name == 'Lasso':
            from sklearn.linear_model import Lasso
            self.estimator = Lasso(**params)
        
    # build selector
    def fit(self, trainX, trainY, threshold=None, max_features = None): 
        self.model = SelectFromModel(self.estimator, threshold=threshold, max_features=max_features)
        print(self.model)
        self.model = self.model.fit(trainX, trainY)
    
    # select features
    def transform(self, trainX):
        return self.model.transform(trainX)

    def fit_and_transform(self, trainX, trainY, n_features = None):
        self.fit(trainX, trainY, threshold=self.threshold, max_features=n_features)
        return self.transform(trainX)