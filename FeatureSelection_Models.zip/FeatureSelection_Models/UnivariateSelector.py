from sklearn.feature_selection import SelectKBest, f_classif
from benchmark import benchmark

class UnivariateSelector:
    def __init__(self, scoring_name, n_features, **params):
        self.scoring_name = scoring_name
        self.scoring = None
        self.model = None
        self.n_features = n_features

        if self.scoring_name == 'f_classif':
            self.scoring = f_classif
        elif self.scoring_name == 'f_regression':
            from sklearn.feature_selection import f_regression
            self.scoring = f_regression
        elif self.scoring_name == 'mutual_info_classif':
            from sklearn.feature_selection import mutual_info_classif
            self.scoring = mutual_info_classif
        elif self.scoring_name == 'mutual_info_regression':
            from sklearn.feature_selection import mutual_info_regression
            self.scoring = mutual_info_regression

    # build selector
    def fit(self, trainX, trainY, n_features):
        self.model = SelectKBest(self.scoring, k=n_features).fit(trainX, trainY)
        print(self.model)
        
    # select features
    def transform(self, trainX):
        return self.model.transform(trainX)

    def fit_and_transform(self, trainX, trainY, n_features):
        self.fit(trainX, trainY, n_features=n_features)
        return self.transform(trainX)